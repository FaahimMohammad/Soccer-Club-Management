﻿namespace Soccer
{
    partial class AddPerformance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbBall = new System.Windows.Forms.ComboBox();
            this.cmbEndur = new System.Windows.Forms.ComboBox();
            this.cmbDef = new System.Windows.Forms.ComboBox();
            this.cmbAttack = new System.Windows.Forms.ComboBox();
            this.cmbFinish = new System.Windows.Forms.ComboBox();
            this.cmbHead = new System.Windows.Forms.ComboBox();
            this.cmbDrib = new System.Windows.Forms.ComboBox();
            this.cmbPass = new System.Windows.Forms.ComboBox();
            this.cmbSpd = new System.Windows.Forms.ComboBox();
            this.txtUid = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.cmbAgg = new System.Windows.Forms.ComboBox();
            this.cmbDriv = new System.Windows.Forms.ComboBox();
            this.cmbStrn = new System.Windows.Forms.ComboBox();
            this.cmbAgil = new System.Windows.Forms.ComboBox();
            this.cmbLeader = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnSrc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "User ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ball Control";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(62, 236);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Passing";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(56, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Dribbling";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(58, 344);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Heading";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 403);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Finishing";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(54, 461);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "In Attack";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(39, 510);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "In Defence";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(40, 567);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Endurance";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(463, 196);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "Speed";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(54, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 20);
            this.label11.TabIndex = 15;
            this.label11.Text = "Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(431, 460);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 20);
            this.label12.TabIndex = 14;
            this.label12.Text = "Leadership";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(406, 405);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 20);
            this.label13.TabIndex = 13;
            this.label13.Text = "Aggresiveness";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(474, 352);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 20);
            this.label14.TabIndex = 12;
            this.label14.Text = "Drive";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(457, 299);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 20);
            this.label15.TabIndex = 11;
            this.label15.Text = "Strenth";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(469, 251);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 20);
            this.label16.TabIndex = 10;
            this.label16.Text = "Agility";
            // 
            // cmbBall
            // 
            this.cmbBall.FormattingEnabled = true;
            this.cmbBall.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbBall.Location = new System.Drawing.Point(147, 182);
            this.cmbBall.Name = "cmbBall";
            this.cmbBall.Size = new System.Drawing.Size(121, 21);
            this.cmbBall.TabIndex = 16;
            // 
            // cmbEndur
            // 
            this.cmbEndur.FormattingEnabled = true;
            this.cmbEndur.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbEndur.Location = new System.Drawing.Point(147, 566);
            this.cmbEndur.Name = "cmbEndur";
            this.cmbEndur.Size = new System.Drawing.Size(121, 21);
            this.cmbEndur.TabIndex = 17;
            // 
            // cmbDef
            // 
            this.cmbDef.FormattingEnabled = true;
            this.cmbDef.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbDef.Location = new System.Drawing.Point(147, 509);
            this.cmbDef.Name = "cmbDef";
            this.cmbDef.Size = new System.Drawing.Size(121, 21);
            this.cmbDef.TabIndex = 18;
            // 
            // cmbAttack
            // 
            this.cmbAttack.FormattingEnabled = true;
            this.cmbAttack.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbAttack.Location = new System.Drawing.Point(147, 460);
            this.cmbAttack.Name = "cmbAttack";
            this.cmbAttack.Size = new System.Drawing.Size(121, 21);
            this.cmbAttack.TabIndex = 19;
            // 
            // cmbFinish
            // 
            this.cmbFinish.FormattingEnabled = true;
            this.cmbFinish.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbFinish.Location = new System.Drawing.Point(147, 402);
            this.cmbFinish.Name = "cmbFinish";
            this.cmbFinish.Size = new System.Drawing.Size(121, 21);
            this.cmbFinish.TabIndex = 20;
            // 
            // cmbHead
            // 
            this.cmbHead.FormattingEnabled = true;
            this.cmbHead.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbHead.Location = new System.Drawing.Point(147, 343);
            this.cmbHead.Name = "cmbHead";
            this.cmbHead.Size = new System.Drawing.Size(121, 21);
            this.cmbHead.TabIndex = 21;
            // 
            // cmbDrib
            // 
            this.cmbDrib.FormattingEnabled = true;
            this.cmbDrib.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbDrib.Location = new System.Drawing.Point(147, 288);
            this.cmbDrib.Name = "cmbDrib";
            this.cmbDrib.Size = new System.Drawing.Size(121, 21);
            this.cmbDrib.TabIndex = 22;
            // 
            // cmbPass
            // 
            this.cmbPass.FormattingEnabled = true;
            this.cmbPass.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbPass.Location = new System.Drawing.Point(147, 235);
            this.cmbPass.Name = "cmbPass";
            this.cmbPass.Size = new System.Drawing.Size(121, 21);
            this.cmbPass.TabIndex = 23;
            // 
            // cmbSpd
            // 
            this.cmbSpd.FormattingEnabled = true;
            this.cmbSpd.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbSpd.Location = new System.Drawing.Point(543, 195);
            this.cmbSpd.Name = "cmbSpd";
            this.cmbSpd.Size = new System.Drawing.Size(121, 21);
            this.cmbSpd.TabIndex = 24;
            // 
            // txtUid
            // 
            this.txtUid.Location = new System.Drawing.Point(129, 43);
            this.txtUid.Name = "txtUid";
            this.txtUid.Size = new System.Drawing.Size(192, 20);
            this.txtUid.TabIndex = 25;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(129, 91);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(192, 20);
            this.txtName.TabIndex = 26;
            // 
            // cmbAgg
            // 
            this.cmbAgg.FormattingEnabled = true;
            this.cmbAgg.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbAgg.Location = new System.Drawing.Point(543, 404);
            this.cmbAgg.Name = "cmbAgg";
            this.cmbAgg.Size = new System.Drawing.Size(121, 21);
            this.cmbAgg.TabIndex = 27;
            // 
            // cmbDriv
            // 
            this.cmbDriv.FormattingEnabled = true;
            this.cmbDriv.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbDriv.Location = new System.Drawing.Point(543, 352);
            this.cmbDriv.Name = "cmbDriv";
            this.cmbDriv.Size = new System.Drawing.Size(121, 21);
            this.cmbDriv.TabIndex = 28;
            // 
            // cmbStrn
            // 
            this.cmbStrn.FormattingEnabled = true;
            this.cmbStrn.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbStrn.Location = new System.Drawing.Point(543, 299);
            this.cmbStrn.Name = "cmbStrn";
            this.cmbStrn.Size = new System.Drawing.Size(121, 21);
            this.cmbStrn.TabIndex = 29;
            // 
            // cmbAgil
            // 
            this.cmbAgil.FormattingEnabled = true;
            this.cmbAgil.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbAgil.Location = new System.Drawing.Point(543, 251);
            this.cmbAgil.Name = "cmbAgil";
            this.cmbAgil.Size = new System.Drawing.Size(121, 21);
            this.cmbAgil.TabIndex = 30;
            // 
            // cmbLeader
            // 
            this.cmbLeader.FormattingEnabled = true;
            this.cmbLeader.Items.AddRange(new object[] {
            "level 1",
            "level 2",
            "level 3"});
            this.cmbLeader.Location = new System.Drawing.Point(543, 460);
            this.cmbLeader.Name = "cmbLeader";
            this.cmbLeader.Size = new System.Drawing.Size(121, 21);
            this.cmbLeader.TabIndex = 31;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(526, 545);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(176, 59);
            this.btnSubmit.TabIndex = 32;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnHome
            // 
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(605, 28);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(127, 47);
            this.btnHome.TabIndex = 33;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnSrc
            // 
            this.btnSrc.Location = new System.Drawing.Point(345, 38);
            this.btnSrc.Name = "btnSrc";
            this.btnSrc.Size = new System.Drawing.Size(85, 32);
            this.btnSrc.TabIndex = 34;
            this.btnSrc.Text = "search";
            this.btnSrc.UseVisualStyleBackColor = true;
            this.btnSrc.Click += new System.EventHandler(this.btnSrc_Click);
            // 
            // AddPerformance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 667);
            this.Controls.Add(this.btnSrc);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.cmbLeader);
            this.Controls.Add(this.cmbAgil);
            this.Controls.Add(this.cmbStrn);
            this.Controls.Add(this.cmbDriv);
            this.Controls.Add(this.cmbAgg);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtUid);
            this.Controls.Add(this.cmbSpd);
            this.Controls.Add(this.cmbPass);
            this.Controls.Add(this.cmbDrib);
            this.Controls.Add(this.cmbHead);
            this.Controls.Add(this.cmbFinish);
            this.Controls.Add(this.cmbAttack);
            this.Controls.Add(this.cmbDef);
            this.Controls.Add(this.cmbEndur);
            this.Controls.Add(this.cmbBall);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddPerformance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Performance";
            this.Load += new System.EventHandler(this.AddPerformance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbBall;
        private System.Windows.Forms.ComboBox cmbEndur;
        private System.Windows.Forms.ComboBox cmbDef;
        private System.Windows.Forms.ComboBox cmbAttack;
        private System.Windows.Forms.ComboBox cmbFinish;
        private System.Windows.Forms.ComboBox cmbHead;
        private System.Windows.Forms.ComboBox cmbDrib;
        private System.Windows.Forms.ComboBox cmbPass;
        private System.Windows.Forms.ComboBox cmbSpd;
        private System.Windows.Forms.TextBox txtUid;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox cmbAgg;
        private System.Windows.Forms.ComboBox cmbDriv;
        private System.Windows.Forms.ComboBox cmbStrn;
        private System.Windows.Forms.ComboBox cmbAgil;
        private System.Windows.Forms.ComboBox cmbLeader;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnSrc;
    }
}